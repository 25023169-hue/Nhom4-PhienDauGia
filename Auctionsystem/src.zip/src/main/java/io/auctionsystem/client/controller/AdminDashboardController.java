package io.auctionsystem.client.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.auctionsystem.client.pattern.SceneManager;
import io.auctionsystem.common.dto.AuthResponse;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

public class AdminDashboardController {

    // =========================
    // KHAI BÁO FXML
    // =========================

    @FXML
    private TableView<AuthResponse> userTable;

    @FXML
    private TableColumn<AuthResponse, Long> colId;

    @FXML
    private TableColumn<AuthResponse, String> colUsername;

    @FXML
    private TableColumn<AuthResponse, String> colFullName;

    @FXML
    private TableColumn<AuthResponse, String> colRole;

    @FXML
    private TableColumn<AuthResponse, Void> colAction;

    @FXML
    private BarChart<String, Number> auctionChart;

    // =========================
    // HTTP + JSON
    // =========================

    private final ObjectMapper objectMapper = new ObjectMapper();

    private final HttpClient httpClient =
            HttpClient.newHttpClient();

    // =========================
    // INITIALIZE
    // =========================

    @FXML
    public void initialize() {

        setupChart();

        setupTable();

        refreshTable();
    }

    // =========================
    // BIỂU ĐỒ
    // =========================

    private void setupChart() {

        XYChart.Series<String, Number> series =
                new XYChart.Series<>();

        series.setName("Số phiên đấu giá 2026");

        series.getData().add(
                new XYChart.Data<>("Tháng 1", 25)
        );

        series.getData().add(
                new XYChart.Data<>("Tháng 2", 40)
        );

        series.getData().add(
                new XYChart.Data<>("Tháng 3", 65)
        );

        auctionChart.getData().add(series);
    }

    // =========================
    // TABLE
    // =========================

    private void setupTable() {

        colId.setCellValueFactory(
                new PropertyValueFactory<>("id")
        );

        colUsername.setCellValueFactory(
                new PropertyValueFactory<>("username")
        );

        colFullName.setCellValueFactory(
                new PropertyValueFactory<>("firstname")
        );

        colRole.setCellValueFactory(
                new PropertyValueFactory<>("role")
        );

        // =========================
        // NÚT KHÓA / MỞ KHÓA
        // =========================

        colAction.setCellFactory(param -> new TableCell<>() {

            private final Button btnToggle =
                    new Button();

            @Override
            protected void updateItem(
                    Void item,
                    boolean empty
            ) {

                super.updateItem(item, empty);

                if (empty) {

                    setGraphic(null);

                } else {

                    AuthResponse user =
                            getTableView()
                                    .getItems()
                                    .get(getIndex());

                    // Nếu bị khóa
                    if (user.isBanned()) {

                        btnToggle.setText("Mở khóa");

                        btnToggle.setStyle(
                                "-fx-background-color: #27ae60;" +
                                        "-fx-text-fill: white;" +
                                        "-fx-cursor: hand;"
                        );

                    }

                    // Nếu chưa bị khóa
                    else {

                        btnToggle.setText("Khóa");

                        btnToggle.setStyle(
                                "-fx-background-color: #e74c3c;" +
                                        "-fx-text-fill: white;" +
                                        "-fx-cursor: hand;"
                        );
                    }

                    btnToggle.setOnAction(event -> {
                        handleToggleBan(user.getId());
                    });

                    setGraphic(btnToggle);
                }
            }
        });
    }

    // =========================
    // LOAD USER
    // =========================

    private void refreshTable() {

        new Thread(() -> {

            try {

                HttpRequest request =
                        HttpRequest.newBuilder()
                                .uri(
                                        URI.create(
                                                "http://localhost:8080/api/admin/users"
                                        )
                                )
                                .GET()
                                .build();

                HttpResponse<String> response =
                        httpClient.send(
                                request,
                                HttpResponse.BodyHandlers.ofString()
                        );

                if (response.statusCode() == 200) {

                    List<AuthResponse> users =
                            objectMapper.readValue(
                                    response.body(),
                                    new TypeReference<List<AuthResponse>>() {
                                    }
                            );

                    Platform.runLater(() -> {

                        userTable.setItems(
                                FXCollections.observableArrayList(users)
                        );

                    });
                }

            } catch (Exception e) {

                System.out.println(
                        "Lỗi load bảng admin: "
                                + e.getMessage()
                );
            }

        }).start();
    }

    // =========================
    // KHÓA / MỞ KHÓA USER
    // =========================

    private void handleToggleBan(Long userId) {

        new Thread(() -> {

            try {

                HttpRequest request =
                        HttpRequest.newBuilder()
                                .uri(
                                        URI.create(
                                                "http://localhost:8080/api/admin/users/toggle-ban/" + userId
                                        )
                                )
                                .PUT(
                                        HttpRequest.BodyPublishers.noBody()
                                )
                                .build();

                HttpResponse<String> response =
                        httpClient.send(
                                request,
                                HttpResponse.BodyHandlers.ofString()
                        );

                if (response.statusCode() == 200) {

                    System.out.println(
                            "Đã đổi trạng thái user "
                                    + userId
                    );

                    refreshTable();
                }

            } catch (Exception e) {

                e.printStackTrace();
            }

        }).start();
    }

    // =========================
    // ĐĂNG XUẤT
    // =========================

    @FXML
    public void onLogout() {

        SceneManager
                .getInstance()
                .switchScene("/client/fxml/login.fxml");
    }
}