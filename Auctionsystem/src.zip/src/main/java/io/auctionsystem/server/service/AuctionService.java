package io.auctionsystem.server.service;

public class AuctionService {
}
